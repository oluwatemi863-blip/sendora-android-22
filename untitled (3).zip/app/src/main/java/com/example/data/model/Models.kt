package com.example.data.model

import android.net.Uri

data class SelectedFile(
    val id: String,
    val uri: Uri,
    val name: String,
    val size: Long,
    val mimeType: String,
    val category: FileCategory
)

data class Device(
    val id: String,
    val name: String,
    val ipAddress: String,
    val port: Int = 8888,
    val isConnected: Boolean = false,
    val lastSeen: Long = System.currentTimeMillis()
)

data class PairingSession(
    val sessionId: String,
    val deviceName: String,
    val ipAddress: String,
    val port: Int = 8888,
    val authToken: String,
    val version: String = "1.0",
    val timestamp: Long = System.currentTimeMillis()
)

data class AppSettings(
    val deviceName: String = "Android Device",
    val themeMode: String = "SYSTEM", // LIGHT, DARK, SYSTEM
    val downloadLocation: String = "Downloads/Sendora",
    val autoAccept: Boolean = false,
    val showNotifications: Boolean = true
)
