package com.example.data.model

enum class FileCategory(val label: String) {
    PHOTOS("Photos"),
    VIDEOS("Videos"),
    MUSIC("Music"),
    DOCUMENTS("Documents"),
    APKS("APKs"),
    ZIPS("ZIP Files"),
    OTHER("Other")
}

enum class TransferStatus {
    IDLE,
    WAITING,
    PENDING,
    CONNECTING,
    TRANSFERRING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED,
    REJECTED
}

enum class TransferDirection {
    SENT,
    RECEIVED
}
