package com.example.data.repository

import android.content.Context
import android.os.Build
import com.example.data.model.AppSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("sendora_prefs", Context.MODE_PRIVATE)

    private val defaultDeviceName: String = run {
        val model = Build.MODEL
        val manufacturer = Build.MANUFACTURER
        if (model.startsWith(manufacturer, ignoreCase = true)) {
            model.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        } else {
            "${manufacturer.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }} $model"
        }
    }

    private val _settings = MutableStateFlow(
        AppSettings(
            deviceName = prefs.getString("device_name", defaultDeviceName) ?: defaultDeviceName,
            themeMode = prefs.getString("theme_mode", "SYSTEM") ?: "SYSTEM",
            downloadLocation = prefs.getString("download_location", "Downloads/Sendora") ?: "Downloads/Sendora",
            autoAccept = prefs.getBoolean("auto_accept", false),
            showNotifications = prefs.getBoolean("show_notifications", true)
        )
    )
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun updateDeviceName(name: String) {
        val newName = name.ifBlank { defaultDeviceName }
        prefs.edit().putString("device_name", newName).apply()
        _settings.value = _settings.value.copy(deviceName = newName)
    }

    fun updateThemeMode(mode: String) {
        prefs.edit().putString("theme_mode", mode).apply()
        _settings.value = _settings.value.copy(themeMode = mode)
    }

    fun updateDownloadLocation(location: String) {
        prefs.edit().putString("download_location", location).apply()
        _settings.value = _settings.value.copy(downloadLocation = location)
    }

    fun updateAutoAccept(enabled: Boolean) {
        prefs.edit().putBoolean("auto_accept", enabled).apply()
        _settings.value = _settings.value.copy(autoAccept = enabled)
    }

    fun updateShowNotifications(enabled: Boolean) {
        prefs.edit().putBoolean("show_notifications", enabled).apply()
        _settings.value = _settings.value.copy(showNotifications = enabled)
    }
}
