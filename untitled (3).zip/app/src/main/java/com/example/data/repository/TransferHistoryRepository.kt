package com.example.data.repository

import com.example.data.database.TransferDao
import com.example.data.database.TransferEntity
import com.example.data.model.TransferDirection
import kotlinx.coroutines.flow.Flow

class TransferHistoryRepository(private val transferDao: TransferDao) {
    val allTransfers: Flow<List<TransferEntity>> = transferDao.getAllTransfers()
    
    fun getTransfersByDirection(direction: TransferDirection): Flow<List<TransferEntity>> {
        return transferDao.getTransfersByDirection(direction.name)
    }

    fun getRecentTransfers(limit: Int = 5): Flow<List<TransferEntity>> {
        return transferDao.getRecentTransfers(limit)
    }

    suspend fun recordTransfer(transfer: TransferEntity): Long {
        return transferDao.insertTransfer(transfer)
    }

    suspend fun deleteTransfer(id: Long) {
        transferDao.deleteById(id)
    }

    suspend fun clearHistory() {
        transferDao.clearAll()
    }
}
