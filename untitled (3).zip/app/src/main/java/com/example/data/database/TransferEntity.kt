package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.FileCategory
import com.example.data.model.TransferDirection
import com.example.data.model.TransferStatus

@Entity(tableName = "transfer_history")
data class TransferEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val fileSize: Long,
    val mimeType: String,
    val categoryName: String,
    val localFilePath: String?,
    val remoteDeviceName: String,
    val statusName: String,
    val directionName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val durationMs: Long = 0,
    val averageSpeedBps: Long = 0
) {
    val category: FileCategory
        get() = try { FileCategory.valueOf(categoryName) } catch (e: Exception) { FileCategory.OTHER }

    val status: TransferStatus
        get() = try { TransferStatus.valueOf(statusName) } catch (e: Exception) { TransferStatus.COMPLETED }

    val direction: TransferDirection
        get() = try { TransferDirection.valueOf(directionName) } catch (e: Exception) { TransferDirection.SENT }
}
