package com.example.network.transfer

import org.json.JSONArray
import org.json.JSONObject

object TransferProtocol {
    const val COMMAND_HANDSHAKE = "HANDSHAKE"
    const val COMMAND_HANDSHAKE_ACK = "HANDSHAKE_ACK"
    const val COMMAND_PROPOSE_FILES = "PROPOSE_FILES"
    const val COMMAND_ACCEPT_FILES = "ACCEPT_FILES"
    const val COMMAND_REJECT_FILES = "REJECT_FILES"
    const val COMMAND_START_FILE = "START_FILE"
    const val COMMAND_END_FILE = "END_FILE"
    const val COMMAND_PAUSE = "PAUSE"
    const val COMMAND_RESUME = "RESUME"
    const val COMMAND_CANCEL = "CANCEL"
    const val COMMAND_DISCONNECT = "DISCONNECT"

    data class FileMeta(
        val index: Int,
        val name: String,
        val size: Long,
        val mimeType: String,
        val categoryName: String
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("index", index)
                put("name", name)
                put("size", size)
                put("mimeType", mimeType)
                put("category", categoryName)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): FileMeta {
                return FileMeta(
                    index = json.getInt("index"),
                    name = json.getString("name"),
                    size = json.getLong("size"),
                    mimeType = json.optString("mimeType", "application/octet-stream"),
                    categoryName = json.optString("category", "OTHER")
                )
            }
        }
    }

    fun buildHandshake(deviceName: String, authToken: String): String {
        return JSONObject().apply {
            put("cmd", COMMAND_HANDSHAKE)
            put("deviceName", deviceName)
            put("authToken", authToken)
            put("version", "1.0")
        }.toString()
    }

    fun buildProposeFiles(deviceName: String, files: List<FileMeta>): String {
        val array = JSONArray()
        files.forEach { array.put(it.toJson()) }
        return JSONObject().apply {
            put("cmd", COMMAND_PROPOSE_FILES)
            put("deviceName", deviceName)
            put("files", array)
        }.toString()
    }

    fun buildResponse(cmd: String, message: String = ""): String {
        return JSONObject().apply {
            put("cmd", cmd)
            put("msg", message)
        }.toString()
    }

    fun buildStartFile(fileMeta: FileMeta): String {
        return JSONObject().apply {
            put("cmd", COMMAND_START_FILE)
            put("file", fileMeta.toJson())
        }.toString()
    }
}
