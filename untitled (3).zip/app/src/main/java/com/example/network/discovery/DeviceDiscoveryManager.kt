package com.example.network.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.util.Log
import com.example.data.model.Device
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections

class DeviceDiscoveryManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val TAG = "SendoraDiscovery"
    private val UDP_PORT = 8889
    private val SERVICE_TYPE = "_sendora._tcp."

    private val _discoveredDevices = MutableStateFlow<List<Device>>(emptyList())
    val discoveredDevices: StateFlow<List<Device>> = _discoveredDevices.asStateFlow()

    private var broadcastJob: Job? = null
    private var listenJob: Job? = null
    private var udpSocket: DatagramSocket? = null
    private val nsdManager: NsdManager by lazy {
        context.getSystemService(Context.NSD_SERVICE) as NsdManager
    }
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    fun startDiscovery(deviceName: String, localPort: Int = 8888) {
        stopDiscovery()
        val localIp = getLocalIpAddress() ?: "127.0.0.1"

        // 1. Start UDP Multicast / Broadcast listener
        listenJob = scope.launch(Dispatchers.IO) {
            try {
                // Acquire Multicast lock for WiFi
                val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                val multicastLock = wifi?.createMulticastLock("SendoraLock")?.apply {
                    setReferenceCounted(true)
                    acquire()
                }

                udpSocket = DatagramSocket(UDP_PORT).apply {
                    broadcast = true
                    reuseAddress = true
                }
                val buffer = ByteArray(2048)

                while (isActive) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    udpSocket?.receive(packet)

                    val senderIp = packet.address.hostAddress ?: continue
                    if (senderIp == localIp) continue // Skip self

                    val jsonStr = String(packet.data, 0, packet.length, Charsets.UTF_8)
                    val json = JSONObject(jsonStr)

                    if (json.optString("app") == "SENDORA") {
                        val peerName = json.optString("name", "Sendora Device")
                        val peerPort = json.optInt("port", 8888)
                        val device = Device(
                            id = "$senderIp:$peerPort",
                            name = peerName,
                            ipAddress = senderIp,
                            port = peerPort,
                            lastSeen = System.currentTimeMillis()
                        )
                        updateDevice(device)
                    }
                }
                multicastLock?.release()
            } catch (e: Exception) {
                Log.e(TAG, "UDP listen error: ${e.message}")
            }
        }

        // 2. Start UDP Broadcast sender
        broadcastJob = scope.launch(Dispatchers.IO) {
            val payload = JSONObject().apply {
                put("app", "SENDORA")
                put("name", deviceName)
                put("port", localPort)
            }.toString().toByteArray(Charsets.UTF_8)

            while (isActive) {
                try {
                    val broadcastAddr = getBroadcastAddress() ?: InetAddress.getByName("255.255.255.255")
                    val packet = DatagramPacket(payload, payload.size, broadcastAddr, UDP_PORT)
                    DatagramSocket().use { socket ->
                        socket.broadcast = true
                        socket.send(packet)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "UDP broadcast send error: ${e.message}")
                }
                delay(3000) // Broadcast ping every 3 seconds
            }
        }

        // 3. Register & Discover NSD
        registerNsdService(deviceName, localPort)
        discoverNsdServices()
    }

    fun stopDiscovery() {
        broadcastJob?.cancel()
        broadcastJob = null
        listenJob?.cancel()
        listenJob = null

        udpSocket?.close()
        udpSocket = null

        unregisterNsdService()
        stopNsdDiscovery()
    }

    private fun updateDevice(device: Device) = synchronized(this) {
        val current = _discoveredDevices.value.toMutableList()
        val index = current.indexOfFirst { it.ipAddress == device.ipAddress }
        if (index != -1) {
            current[index] = device
        } else {
            current.add(device)
        }
        _discoveredDevices.value = current
    }

    fun getLocalIpAddress(): String? {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress && !addr.isLinkLocalAddress) {
                        val host = addr.hostAddress
                        if (host != null && host.indexOf(':') < 0) { // IPv4
                            return host
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    private fun getBroadcastAddress(): InetAddress? {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                if (intf.isLoopback || !intf.isUp) continue
                for (addr in intf.interfaceAddresses) {
                    val broadcast = addr.broadcast
                    if (broadcast != null) {
                        return broadcast
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    private fun registerNsdService(deviceName: String, port: Int) {
        val serviceInfo = NsdServiceInfo().apply {
            serviceName = "Sendora_$deviceName"
            serviceType = SERVICE_TYPE
            setPort(port)
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(NsdServiceInfo: NsdServiceInfo) {}
            override fun onRegistrationFailed(arg0: NsdServiceInfo, arg1: Int) {}
            override fun onServiceUnregistered(arg0: NsdServiceInfo) {}
            override fun onUnregistrationFailed(arg0: NsdServiceInfo, arg1: Int) {}
        }

        try {
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
        } catch (e: Exception) {
            Log.e(TAG, "NSD register error: ${e.message}")
        }
    }

    private fun discoverNsdServices() {
        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {}
            override fun onServiceFound(service: NsdServiceInfo) {
                if (service.serviceType == SERVICE_TYPE && service.serviceName.contains("Sendora_")) {
                    nsdManager.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            val hostIp = serviceInfo.host?.hostAddress ?: return
                            val name = serviceInfo.serviceName.removePrefix("Sendora_")
                            val device = Device(
                                id = "$hostIp:${serviceInfo.port}",
                                name = name,
                                ipAddress = hostIp,
                                port = serviceInfo.port
                            )
                            updateDevice(device)
                        }
                    })
                }
            }

            override fun onServiceLost(service: NsdServiceInfo) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                nsdManager.stopServiceDiscovery(this)
            }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }

        try {
            nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            Log.e(TAG, "NSD discovery error: ${e.message}")
        }
    }

    private fun unregisterNsdService() {
        registrationListener?.let {
            try { nsdManager.unregisterService(it) } catch (e: Exception) {}
            registrationListener = null
        }
    }

    private fun stopNsdDiscovery() {
        discoveryListener?.let {
            try { nsdManager.stopServiceDiscovery(it) } catch (e: Exception) {}
            discoveryListener = null
        }
    }
}
