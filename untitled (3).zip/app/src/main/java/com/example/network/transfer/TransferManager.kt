package com.example.network.transfer

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.database.AppDatabase
import com.example.data.database.TransferEntity
import com.example.data.model.FileCategory
import com.example.data.model.SelectedFile
import com.example.data.model.TransferDirection
import com.example.data.model.TransferStatus
import com.example.notifications.SendoraNotificationManager
import com.example.storage.FileManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.Locale
import java.util.UUID

data class TransferQueueItem(
    val id: String,
    val name: String,
    val size: Long,
    val mimeType: String,
    val category: FileCategory,
    val uri: Uri? = null,
    val direction: TransferDirection = TransferDirection.SENT,
    var status: TransferStatus = TransferStatus.WAITING,
    var bytesTransferred: Long = 0L,
    var progressPercent: Int = 0,
    var speedText: String = "0 KB/s",
    var savedPath: String? = null,
    var errorMessage: String? = null
)

class TransferManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val TAG = "SendoraTransferManager"
    private val fileManager = FileManager(context)
    private val notificationManager = SendoraNotificationManager(context)
    private val db = AppDatabase.getInstance(context)

    data class IncomingProposal(
        val senderName: String,
        val files: List<TransferProtocol.FileMeta>,
        val totalSize: Long
    )

    data class ActiveTransferState(
        val isConnected: Boolean = false,
        val remoteDeviceName: String = "",
        val remoteIp: String = "",
        val status: TransferStatus = TransferStatus.IDLE,
        val isReceiver: Boolean = false,
        val queue: List<TransferQueueItem> = emptyList(),
        val activeIndex: Int = 0,
        val totalSize: Long = 0L,
        val totalBytesTransferred: Long = 0L,
        val overallProgressPercent: Int = 0,
        val speedBps: Long = 0L,
        val speedText: String = "0 KB/s",
        val remainingSeconds: Long = 0L,
        val errorMessage: String? = null,
        val incomingProposal: IncomingProposal? = null
    ) {
        val progressPercent: Int get() = overallProgressPercent
        val currentFileName: String get() = queue.getOrNull(activeIndex)?.name ?: ""
        val currentFileIndex: Int get() = if (queue.isNotEmpty()) activeIndex + 1 else 0
        val currentFileSize: Long get() = queue.getOrNull(activeIndex)?.size ?: 0L
        val currentBytesTransferred: Long get() = queue.getOrNull(activeIndex)?.bytesTransferred ?: 0L
        val filesCount: Int get() = queue.size
    }

    private val _transferState = MutableStateFlow(ActiveTransferState())
    val transferState: StateFlow<ActiveTransferState> = _transferState.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    private var activeSocket: Socket? = null
    private var dataInStream: DataInputStream? = null
    private var dataOutStream: DataOutputStream? = null

    private var readerJob: Job? = null
    private var activeSendJob: Job? = null

    @Volatile
    private var isPaused = false
    @Volatile
    private var isCancelled = false

    fun startServer(deviceName: String, port: Int = 8888) {
        stopServer()
        serverJob = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket(port)
                Log.d(TAG, "Server socket bound on port $port")

                while (isActive) {
                    val socket = serverSocket?.accept() ?: break
                    Log.d(TAG, "Server accepted socket connection from ${socket.inetAddress.hostAddress}")
                    if (activeSocket == null || activeSocket?.isClosed == true) {
                        setupActiveSocketSession(socket, deviceName, isServer = true)
                    }
                }
            } catch (e: Exception) {
                if (isActive) Log.e(TAG, "Server socket error: ${e.message}")
            }
        }
    }

    fun stopServer() {
        serverJob?.cancel()
        serverJob = null
        try {
            serverSocket?.close()
        } catch (e: Exception) {}
        serverSocket = null
    }

    suspend fun connectToDevice(ip: String, port: Int, myDeviceName: String): Boolean = withContext(Dispatchers.IO) {
        try {
            if (activeSocket != null && !activeSocket!!.isClosed && _transferState.value.isConnected) {
                Log.d(TAG, "Already connected to ${_transferState.value.remoteDeviceName}")
                return@withContext true
            }

            _transferState.value = _transferState.value.copy(
                status = TransferStatus.CONNECTING,
                errorMessage = null
            )

            Log.d(TAG, "Connecting to socket at $ip:$port...")
            val socket = Socket(ip, port)
            setupActiveSocketSession(socket, myDeviceName, isServer = false)
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Connection failed to $ip:$port: ${e.message}")
            _transferState.value = _transferState.value.copy(
                status = TransferStatus.FAILED,
                errorMessage = "Failed to connect to device at $ip: ${e.message}"
            )
            return@withContext false
        }
    }

    private fun setupActiveSocketSession(socket: Socket, myDeviceName: String, isServer: Boolean) {
        try {
            activeSocket = socket
            dataInStream = DataInputStream(socket.getInputStream())
            dataOutStream = DataOutputStream(socket.getOutputStream())

            val dis = dataInStream!!
            val dos = dataOutStream!!

            // Handshake protocol
            if (!isServer) {
                dos.writeUTF(TransferProtocol.buildHandshake(myDeviceName, "AUTH_TOKEN_SENDORA"))
                dos.flush()
            }

            val handshakeResp = dis.readUTF()
            val jsonResp = JSONObject(handshakeResp)
            val remoteName = jsonResp.optString("deviceName", "Remote Device")

            if (isServer) {
                dos.writeUTF(TransferProtocol.buildHandshake(myDeviceName, "AUTH_TOKEN_SENDORA"))
                dos.flush()
            }

            _transferState.value = _transferState.value.copy(
                isConnected = true,
                remoteDeviceName = remoteName,
                remoteIp = socket.inetAddress.hostAddress ?: "",
                status = TransferStatus.IDLE,
                errorMessage = null
            )

            Log.d(TAG, "Active socket session established with $remoteName (${socket.inetAddress.hostAddress})")

            startSocketReaderLoop(socket, dis, dos)

        } catch (e: Exception) {
            Log.e(TAG, "Socket session setup failed: ${e.message}")
            disconnect()
        }
    }

    private fun startSocketReaderLoop(socket: Socket, dis: DataInputStream, dos: DataOutputStream) {
        readerJob?.cancel()
        readerJob = scope.launch(Dispatchers.IO) {
            try {
                while (isActive && !socket.isClosed) {
                    val frameStr = dis.readUTF()
                    val frameJson = JSONObject(frameStr)
                    val cmd = frameJson.optString("cmd")

                    when (cmd) {
                        TransferProtocol.COMMAND_PROPOSE_FILES -> {
                            handleIncomingProposalFrame(frameJson, dos)
                        }

                        TransferProtocol.COMMAND_ACCEPT_FILES -> {
                            Log.d(TAG, "Remote accepted proposed files queue")
                        }

                        TransferProtocol.COMMAND_START_FILE -> {
                            handleIncomingStartFileFrame(frameJson, dis)
                        }

                        TransferProtocol.COMMAND_CANCEL -> {
                            handleIncomingCancelFrame()
                        }

                        TransferProtocol.COMMAND_DISCONNECT -> {
                            Log.d(TAG, "Received disconnect command from peer")
                            disconnect()
                            break
                        }
                    }
                }
            } catch (e: Exception) {
                if (isActive && !socket.isClosed) {
                    Log.e(TAG, "Reader loop exception: ${e.message}")
                }
                disconnect()
            }
        }
    }

    private fun handleIncomingProposalFrame(json: JSONObject, dos: DataOutputStream) {
        val senderName = json.optString("deviceName", "Sender")
        val filesArray = json.optJSONArray("files") ?: JSONArray()
        val incomingQueue = mutableListOf<TransferQueueItem>()

        var totalSize = 0L
        for (i in 0 until filesArray.length()) {
            val metaObj = filesArray.getJSONObject(i)
            val meta = TransferProtocol.FileMeta.fromJson(metaObj)
            val cat = try {
                FileCategory.valueOf(meta.categoryName)
            } catch (e: Exception) {
                FileCategory.OTHER
            }
            val queueItem = TransferQueueItem(
                id = "rx_${UUID.randomUUID()}",
                name = meta.name,
                size = meta.size,
                mimeType = meta.mimeType,
                category = cat,
                direction = TransferDirection.RECEIVED,
                status = TransferStatus.WAITING
            )
            incomingQueue.add(queueItem)
            totalSize += meta.size
        }

        val updatedList = _transferState.value.queue + incomingQueue

        _transferState.value = _transferState.value.copy(
            isReceiver = true,
            status = TransferStatus.TRANSFERRING,
            remoteDeviceName = senderName,
            queue = updatedList,
            totalSize = updatedList.sumOf { it.size },
            errorMessage = null
        )

        try {
            dos.writeUTF(TransferProtocol.buildResponse(TransferProtocol.COMMAND_ACCEPT_FILES, "Accepted"))
            dos.flush()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to respond to file proposal: ${e.message}")
        }
    }

    private suspend fun handleIncomingStartFileFrame(json: JSONObject, dis: DataInputStream) = withContext(Dispatchers.IO) {
        val metaObj = json.getJSONObject("file")
        val meta = TransferProtocol.FileMeta.fromJson(metaObj)

        val currentQueue = _transferState.value.queue.toMutableList()
        val queueIndex = currentQueue.indexOfFirst { it.name == meta.name && it.direction == TransferDirection.RECEIVED && it.status == TransferStatus.WAITING }
        
        val itemToReceive = if (queueIndex != -1) {
            currentQueue[queueIndex].copy(status = TransferStatus.TRANSFERRING)
        } else {
            val newItem = TransferQueueItem(
                id = "rx_${UUID.randomUUID()}",
                name = meta.name,
                size = meta.size,
                mimeType = meta.mimeType,
                category = try { FileCategory.valueOf(meta.categoryName) } catch (e: Exception) { FileCategory.OTHER },
                direction = TransferDirection.RECEIVED,
                status = TransferStatus.TRANSFERRING
            )
            currentQueue.add(newItem)
            newItem
        }

        val targetIdx = if (queueIndex != -1) queueIndex else currentQueue.size - 1
        currentQueue[targetIdx] = itemToReceive

        _transferState.value = _transferState.value.copy(
            queue = currentQueue,
            activeIndex = targetIdx,
            status = TransferStatus.TRANSFERRING
        )

        val outResult = fileManager.createDownloadOutputStream(meta.name, meta.mimeType)
        val buffer = ByteArray(128 * 1024)
        var bytesRemaining = meta.size
        var bytesReadTotal = 0L
        val startTime = System.currentTimeMillis()
        var lastUpdate = System.currentTimeMillis()
        var bytesSinceUpdate = 0L

        try {
            outResult.outputStream.use { outStream ->
                while (bytesRemaining > 0) {
                    val toRead = Math.min(buffer.size.toLong(), bytesRemaining).toInt()
                    val read = dis.read(buffer, 0, toRead)
                    if (read == -1) break

                    outStream.write(buffer, 0, read)
                    bytesRemaining -= read
                    bytesReadTotal += read
                    bytesSinceUpdate += read

                    val now = System.currentTimeMillis()
                    val timeDiff = now - lastUpdate
                    if (timeDiff >= 400) {
                        val bps = (bytesSinceUpdate * 1000) / timeDiff
                        val filePct = if (meta.size > 0) ((bytesReadTotal * 100) / meta.size).toInt() else 0
                        val speedTxt = formatSpeed(bps)

                        val qList = _transferState.value.queue.toMutableList()
                        if (targetIdx < qList.size) {
                            qList[targetIdx] = qList[targetIdx].copy(
                                bytesTransferred = bytesReadTotal,
                                progressPercent = filePct,
                                speedText = speedTxt,
                                status = TransferStatus.TRANSFERRING
                            )
                        }

                        val overallTransferred = qList.sumOf { it.bytesTransferred }
                        val overallPct = if (_transferState.value.totalSize > 0) ((overallTransferred * 100) / _transferState.value.totalSize).toInt() else 0

                        _transferState.value = _transferState.value.copy(
                            queue = qList,
                            totalBytesTransferred = overallTransferred,
                            overallProgressPercent = overallPct,
                            speedBps = bps,
                            speedText = speedTxt
                        )

                        lastUpdate = now
                        bytesSinceUpdate = 0
                    }
                }
            }

            val qList = _transferState.value.queue.toMutableList()
            if (targetIdx < qList.size) {
                qList[targetIdx] = qList[targetIdx].copy(
                    bytesTransferred = meta.size,
                    progressPercent = 100,
                    status = TransferStatus.COMPLETED,
                    savedPath = outResult.savedPath
                )
            }

            val overallTransferred = qList.sumOf { it.bytesTransferred }
            val overallPct = if (_transferState.value.totalSize > 0) ((overallTransferred * 100) / _transferState.value.totalSize).toInt() else 0

            _transferState.value = _transferState.value.copy(
                queue = qList,
                totalBytesTransferred = overallTransferred,
                overallProgressPercent = overallPct
            )

            saveHistoryRecord(
                fileName = meta.name,
                fileSize = meta.size,
                mimeType = meta.mimeType,
                category = try { FileCategory.valueOf(meta.categoryName) } catch (e: Exception) { FileCategory.OTHER },
                path = outResult.savedPath,
                remoteName = _transferState.value.remoteDeviceName,
                status = TransferStatus.COMPLETED,
                direction = TransferDirection.RECEIVED,
                durationMs = System.currentTimeMillis() - startTime
            )

            // Notify on file completion
            notificationManager.showTransferCompleted(
                fileName = meta.name,
                totalFiles = 1,
                totalSizeText = formatSize(meta.size)
            )

        } catch (e: Exception) {
            Log.e(TAG, "Error receiving file ${meta.name}: ${e.message}")
            val qList = _transferState.value.queue.toMutableList()
            if (targetIdx < qList.size) {
                qList[targetIdx] = qList[targetIdx].copy(
                    status = TransferStatus.FAILED,
                    errorMessage = e.message
                )
            }
            _transferState.value = _transferState.value.copy(queue = qList)
        }
    }

    private fun handleIncomingCancelFrame() {
        isCancelled = true
        _transferState.value = _transferState.value.copy(status = TransferStatus.CANCELLED)
    }

    fun sendFilesToDevice(targetIp: String, targetPort: Int, files: List<SelectedFile>, myDeviceName: String) {
        scope.launch(Dispatchers.IO) {
            val connected = connectToDevice(targetIp, targetPort, myDeviceName)
            if (connected) {
                sendSelectedFiles(files, myDeviceName)
            }
        }
    }

    fun sendSelectedFiles(files: List<SelectedFile>, myDeviceName: String) {
        if (files.isEmpty()) return

        isPaused = false
        isCancelled = false

        activeSendJob?.cancel()
        activeSendJob = scope.launch(Dispatchers.IO) {
            val dos = dataOutStream
            val socket = activeSocket

            if (dos == null || socket == null || socket.isClosed || !_transferState.value.isConnected) {
                _transferState.value = _transferState.value.copy(
                    status = TransferStatus.FAILED,
                    errorMessage = "No active connection. Please connect to a device first."
                )
                return@launch
            }

            val newSendItems = files.map { sf ->
                TransferQueueItem(
                    id = "tx_${UUID.randomUUID()}",
                    name = sf.name,
                    size = sf.size,
                    mimeType = sf.mimeType,
                    category = sf.category,
                    uri = sf.uri,
                    direction = TransferDirection.SENT,
                    status = TransferStatus.WAITING
                )
            }

            val fileMetas = newSendItems.mapIndexed { idx, item ->
                TransferProtocol.FileMeta(
                    index = idx,
                    name = item.name,
                    size = item.size,
                    mimeType = item.mimeType,
                    categoryName = item.category.name
                )
            }

            val updatedQueue = _transferState.value.queue + newSendItems
            val totalQueueSize = updatedQueue.sumOf { it.size }

            _transferState.value = _transferState.value.copy(
                isReceiver = false,
                status = TransferStatus.TRANSFERRING,
                queue = updatedQueue,
                totalSize = totalQueueSize,
                errorMessage = null
            )

            try {
                val proposeFrame = TransferProtocol.buildProposeFiles(myDeviceName, fileMetas)
                dos.writeUTF(proposeFrame)
                dos.flush()

                for (item in newSendItems) {
                    if (isCancelled) break

                    val itemIdx = _transferState.value.queue.indexOfFirst { it.id == item.id }
                    if (itemIdx != -1) {
                        val qList = _transferState.value.queue.toMutableList()
                        qList[itemIdx] = qList[itemIdx].copy(status = TransferStatus.TRANSFERRING)
                        _transferState.value = _transferState.value.copy(
                            queue = qList,
                            activeIndex = itemIdx
                        )
                    }

                    val meta = TransferProtocol.FileMeta(
                        index = itemIdx,
                        name = item.name,
                        size = item.size,
                        mimeType = item.mimeType,
                        categoryName = item.category.name
                    )

                    dos.writeUTF(TransferProtocol.buildStartFile(meta))
                    dos.flush()

                    val inputStream = item.uri?.let { fileManager.openInputStream(it) }
                    if (inputStream == null) {
                        Log.e(TAG, "Cannot open input stream for ${item.name}")
                        val qList = _transferState.value.queue.toMutableList()
                        if (itemIdx != -1) {
                            qList[itemIdx] = qList[itemIdx].copy(
                                status = TransferStatus.FAILED,
                                errorMessage = "File input stream unavailable"
                            )
                        }
                        _transferState.value = _transferState.value.copy(queue = qList)
                        continue
                    }

                    val buffer = ByteArray(128 * 1024)
                    var bytesRead: Int
                    var fileSent = 0L
                    val startTime = System.currentTimeMillis()
                    var lastUpdate = System.currentTimeMillis()
                    var bytesSinceUpdate = 0L

                    inputStream.use { stream ->
                        while (stream.read(buffer).also { bytesRead = it } != -1) {
                            if (isCancelled) break
                            while (isPaused) {
                                delay(200)
                                if (isCancelled) break
                            }

                            dos.write(buffer, 0, bytesRead)
                            dos.flush()

                            fileSent += bytesRead
                            bytesSinceUpdate += bytesRead

                            val now = System.currentTimeMillis()
                            val timeDiff = now - lastUpdate
                            if (timeDiff >= 400) {
                                val bps = (bytesSinceUpdate * 1000) / timeDiff
                                val filePct = if (item.size > 0) ((fileSent * 100) / item.size).toInt() else 0
                                val speedTxt = formatSpeed(bps)

                                val qList = _transferState.value.queue.toMutableList()
                                if (itemIdx != -1 && itemIdx < qList.size) {
                                    qList[itemIdx] = qList[itemIdx].copy(
                                        bytesTransferred = fileSent,
                                        progressPercent = filePct,
                                        speedText = speedTxt,
                                        status = TransferStatus.TRANSFERRING
                                    )
                                }

                                val overallTransferred = qList.sumOf { it.bytesTransferred }
                                val overallPct = if (_transferState.value.totalSize > 0) ((overallTransferred * 100) / _transferState.value.totalSize).toInt() else 0

                                _transferState.value = _transferState.value.copy(
                                    queue = qList,
                                    totalBytesTransferred = overallTransferred,
                                    overallProgressPercent = overallPct,
                                    speedBps = bps,
                                    speedText = speedTxt
                                )

                                lastUpdate = now
                                bytesSinceUpdate = 0
                            }
                        }
                    }

                    if (isCancelled) break

                    val qList = _transferState.value.queue.toMutableList()
                    if (itemIdx != -1 && itemIdx < qList.size) {
                        qList[itemIdx] = qList[itemIdx].copy(
                            bytesTransferred = item.size,
                            progressPercent = 100,
                            status = TransferStatus.COMPLETED
                        )
                    }

                    val overallTransferred = qList.sumOf { it.bytesTransferred }
                    val overallPct = if (_transferState.value.totalSize > 0) ((overallTransferred * 100) / _transferState.value.totalSize).toInt() else 0

                    _transferState.value = _transferState.value.copy(
                        queue = qList,
                        totalBytesTransferred = overallTransferred,
                        overallProgressPercent = overallPct
                    )

                    saveHistoryRecord(
                        fileName = item.name,
                        fileSize = item.size,
                        mimeType = item.mimeType,
                        category = item.category,
                        path = item.uri?.toString() ?: "",
                        remoteName = _transferState.value.remoteDeviceName,
                        status = TransferStatus.COMPLETED,
                        direction = TransferDirection.SENT,
                        durationMs = System.currentTimeMillis() - startTime
                    )
                }

                if (isCancelled) {
                    _transferState.value = _transferState.value.copy(status = TransferStatus.CANCELLED)
                } else {
                    _transferState.value = _transferState.value.copy(
                        status = TransferStatus.COMPLETED,
                        overallProgressPercent = 100
                    )
                }

            } catch (e: Exception) {
                Log.e(TAG, "Send queue error: ${e.message}")
                _transferState.value = _transferState.value.copy(
                    status = TransferStatus.FAILED,
                    errorMessage = e.message ?: "Transfer error occurred"
                )
            }
        }
    }

    fun acceptIncomingTransfer(proposal: IncomingProposal) {
        _transferState.value = _transferState.value.copy(incomingProposal = null)
    }

    fun rejectIncomingTransfer(proposal: IncomingProposal) {
        _transferState.value = _transferState.value.copy(incomingProposal = null)
    }

    fun resetState() {
        _transferState.value = ActiveTransferState(
            isConnected = _transferState.value.isConnected,
            remoteDeviceName = _transferState.value.remoteDeviceName,
            remoteIp = _transferState.value.remoteIp,
            status = TransferStatus.IDLE
        )
    }

    fun pauseTransfer() {
        isPaused = true
    }

    fun resumeTransfer() {
        isPaused = false
    }

    fun cancelTransfer() {
        isCancelled = true
        scope.launch(Dispatchers.IO) {
            try {
                dataOutStream?.writeUTF(TransferProtocol.buildResponse(TransferProtocol.COMMAND_CANCEL))
                dataOutStream?.flush()
            } catch (e: Exception) {}
        }
    }

    fun disconnect() {
        readerJob?.cancel()
        readerJob = null
        activeSendJob?.cancel()
        activeSendJob = null

        scope.launch(Dispatchers.IO) {
            try {
                dataOutStream?.writeUTF(TransferProtocol.buildResponse(TransferProtocol.COMMAND_DISCONNECT))
                dataOutStream?.flush()
            } catch (e: Exception) {}
            try {
                activeSocket?.close()
            } catch (e: Exception) {}

            activeSocket = null
            dataInStream = null
            dataOutStream = null

            _transferState.value = ActiveTransferState(
                isConnected = false,
                status = TransferStatus.IDLE
            )
        }
    }

    private fun saveHistoryRecord(
        fileName: String,
        fileSize: Long,
        mimeType: String,
        category: FileCategory,
        path: String,
        remoteName: String,
        status: TransferStatus,
        direction: TransferDirection,
        durationMs: Long
    ) {
        scope.launch(Dispatchers.IO) {
            try {
                db.transferDao().insertTransfer(
                    TransferEntity(
                        fileName = fileName,
                        fileSize = fileSize,
                        mimeType = mimeType,
                        categoryName = category.name,
                        localFilePath = path,
                        remoteDeviceName = remoteName,
                        statusName = status.name,
                        directionName = direction.name,
                        durationMs = durationMs
                    )
                )
            } catch (e: Exception) {
                Log.e(TAG, "Database save error: ${e.message}")
            }
        }
    }

    private fun formatSpeed(bps: Long): String {
        return when {
            bps >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bps / (1024.0 * 1024.0))
            bps >= 1024 -> String.format(Locale.US, "%.1f KB/s", bps / 1024.0)
            else -> "$bps B/s"
        }
    }

    private fun formatSize(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
            bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
            bytes >= 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
            else -> "$bytes B"
        }
    }
}
