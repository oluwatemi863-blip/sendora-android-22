package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.database.TransferEntity
import com.example.data.model.FileCategory
import com.example.data.model.SelectedFile
import com.example.data.model.TransferDirection
import com.example.data.model.TransferStatus
import com.example.data.repository.AppContentItem
import com.example.data.repository.LocalContentRepository
import com.example.data.repository.LocalMediaItem
import com.example.data.repository.SettingsRepository
import com.example.data.repository.TransferHistoryRepository
import com.example.network.transfer.TransferManager
import com.example.storage.FileManager
import com.example.ui.components.SendoraCard
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SendoraDarkBorder
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class MainTab(val title: String) {
    HISTORY("History"),
    APPS("Apps"),
    PHOTOS("Photos"),
    VIDEOS("Videos"),
    MUSIC("Music"),
    FILES("Files")
}

@Composable
fun HomeScreen(
    settingsRepository: SettingsRepository,
    historyRepository: TransferHistoryRepository,
    transferManager: TransferManager,
    onNavigateToSend: (List<SelectedFile>) -> Unit,
    onNavigateToReceive: () -> Unit,
    onNavigateToConnect: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val localRepo = remember { LocalContentRepository(context) }
    val fileManager = remember { FileManager(context) }

    val settings by settingsRepository.settings.collectAsStateWithLifecycle()
    val transferState by transferManager.transferState.collectAsStateWithLifecycle()
    val historyList by historyRepository.allTransfers.collectAsStateWithLifecycle(initialValue = emptyList())

    var selectedTab by remember { mutableStateOf(MainTab.APPS) }
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }

    // Selected files set
    val selectedFiles = remember { mutableStateListOf<SelectedFile>() }

    // Local content states
    var installedApps by remember { mutableStateOf<List<AppContentItem>>(emptyList()) }
    var localPhotos by remember { mutableStateOf<List<LocalMediaItem>>(emptyList()) }
    var localVideos by remember { mutableStateOf<List<LocalMediaItem>>(emptyList()) }
    var localMusic by remember { mutableStateOf<List<LocalMediaItem>>(emptyList()) }
    var localFiles by remember { mutableStateOf<List<LocalMediaItem>>(emptyList()) }

    var isLoadingApps by remember { mutableStateOf(true) }

    // External file picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        uris.forEach { uri ->
            val info = fileManager.getFileInfoFromUri(uri)
            if (info != null && selectedFiles.none { it.uri == uri }) {
                selectedFiles.add(info)
            }
        }
    }

    LaunchedEffect(Unit) {
        scope.launch {
            installedApps = localRepo.getInstalledApps()
            isLoadingApps = false
        }
        scope.launch { localPhotos = localRepo.getLocalPhotos() }
        scope.launch { localVideos = localRepo.getLocalVideos() }
        scope.launch { localMusic = localRepo.getLocalMusic() }
        scope.launch { localFiles = localRepo.getLocalFiles() }
    }

    Scaffold(
        topBar = {
            Column(modifier = Modifier.background(MaterialTheme.colorScheme.background)) {
                // Main Header Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onNavigateToSettings) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Menu",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Transfer",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 22.sp
                            ),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (transferState.isConnected) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(CyanAccent.copy(alpha = 0.2f))
                                    .clickable { onNavigateToConnect() }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(CyanAccent)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = transferState.remoteDeviceName,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = CyanAccent,
                                        maxLines = 1
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        IconButton(onClick = { isSearchActive = !isSearchActive }) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        IconButton(onClick = { filePickerLauncher.launch("*/*") }) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Files",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }

                if (isSearchActive) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search local content...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = SendoraDarkBorder
                        )
                    )
                }

                // Category Scrollable Tabs (History | Apps | Photos | Videos | Music | Files)
                ScrollableTabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.background,
                    contentColor = ElectricBlue,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                            height = 3.dp,
                            color = ElectricBlue
                        )
                    }
                ) {
                    MainTab.values().forEach { tab ->
                        Tab(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            text = {
                                Text(
                                    text = tab.title,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = if (selectedTab == tab) ElectricBlue else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        )
                    }
                }
            }
        },
        bottomBar = {
            BottomTransferActionBar(
                selectedCount = selectedFiles.size,
                totalSizeBytes = selectedFiles.sumOf { it.size },
                isConnected = transferState.isConnected,
                connectedDeviceName = transferState.remoteDeviceName,
                onSend = {
                    if (selectedFiles.isNotEmpty()) {
                        onNavigateToSend(selectedFiles.toList())
                    } else {
                        onNavigateToConnect()
                    }
                },
                onReceive = onNavigateToReceive,
                onConnect = onNavigateToConnect,
                onClear = { selectedFiles.clear() }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (selectedTab) {
                MainTab.APPS -> AppsTabContent(
                    apps = installedApps.filter { it.name.contains(searchQuery, ignoreCase = true) },
                    selectedFiles = selectedFiles,
                    isLoading = isLoadingApps
                )
                MainTab.PHOTOS -> PhotosTabContent(
                    photos = localPhotos.filter { it.name.contains(searchQuery, ignoreCase = true) },
                    selectedFiles = selectedFiles,
                    onPickExternal = { filePickerLauncher.launch("image/*") }
                )
                MainTab.VIDEOS -> VideosTabContent(
                    videos = localVideos.filter { it.name.contains(searchQuery, ignoreCase = true) },
                    selectedFiles = selectedFiles,
                    onPickExternal = { filePickerLauncher.launch("video/*") }
                )
                MainTab.MUSIC -> MusicTabContent(
                    musicList = localMusic.filter { it.name.contains(searchQuery, ignoreCase = true) || it.artist.contains(searchQuery, ignoreCase = true) },
                    selectedFiles = selectedFiles,
                    onPickExternal = { filePickerLauncher.launch("audio/*") }
                )
                MainTab.FILES -> FilesTabContent(
                    files = localFiles.filter { it.name.contains(searchQuery, ignoreCase = true) },
                    selectedFiles = selectedFiles,
                    onPickExternal = { filePickerLauncher.launch("*/*") }
                )
                MainTab.HISTORY -> HistoryTabContent(
                    historyList = historyList,
                    fileManager = fileManager
                )
            }
        }
    }
}

@Composable
private fun AppsTabContent(
    apps: List<AppContentItem>,
    selectedFiles: MutableList<SelectedFile>,
    isLoading: Boolean
) {
    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Scanning installed applications...", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }

    val hotApps = apps.filter { it.isHot }
    val localApps = apps.filter { !it.isHot }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (hotApps.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Hot",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    hotApps.take(2).forEach { app ->
                        AppHotCard(
                            app = app,
                            isSelected = selectedFiles.any { it.id == app.packageName },
                            onToggle = { toggleAppSelection(app, selectedFiles) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Local Apps (${apps.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // 4-Column Grid for Apps
        item {
            val chunked = (if (localApps.isNotEmpty()) localApps else apps).chunked(4)
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                chunked.forEach { rowApps ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (i in 0 until 4) {
                            if (i < rowApps.size) {
                                val app = rowApps[i]
                                AppGridCard(
                                    app = app,
                                    isSelected = selectedFiles.any { it.id == app.packageName },
                                    onToggle = { toggleAppSelection(app, selectedFiles) },
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(120.dp))
        }
    }
}

@Composable
private fun AppHotCard(
    app: AppContentItem,
    isSelected: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onToggle() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) ElectricBlue.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) ElectricBlue else SendoraDarkBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIconImage(iconDrawable = app.icon, modifier = Modifier.size(44.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = app.name,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = formatSize(app.size),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun AppGridCard(
    app: AppContentItem,
    isSelected: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onToggle() }
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            AppIconImage(iconDrawable = app.icon, modifier = Modifier.size(52.dp))
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(ElectricBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = app.name,
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = formatSize(app.size),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
    }
}

@Composable
private fun AppIconImage(iconDrawable: Drawable?, modifier: Modifier = Modifier) {
    if (iconDrawable != null) {
        val bitmap = remember(iconDrawable) {
            try {
                iconDrawable.toBitmap(96, 96)
            } catch (e: Exception) {
                null
            }
        }
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                modifier = modifier.clip(RoundedCornerShape(12.dp))
            )
            return
        }
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(ElectricBlue.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Android,
            contentDescription = null,
            tint = ElectricBlue,
            modifier = Modifier.size(28.dp)
        )
    }
}

private fun toggleAppSelection(app: AppContentItem, selectedFiles: MutableList<SelectedFile>) {
    val existing = selectedFiles.find { it.id == app.packageName }
    if (existing != null) {
        selectedFiles.remove(existing)
    } else {
        selectedFiles.add(
            SelectedFile(
                id = app.packageName,
                uri = app.uri,
                name = "${app.name}.apk",
                size = app.size,
                mimeType = "application/vnd.android.package-archive",
                category = FileCategory.APKS
            )
        )
    }
}

@Composable
private fun PhotosTabContent(
    photos: List<LocalMediaItem>,
    selectedFiles: MutableList<SelectedFile>,
    onPickExternal: () -> Unit
) {
    var isAllSelected by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Photos (${photos.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (isAllSelected) "Deselect All" else "Select All",
                    style = MaterialTheme.typography.labelLarge,
                    color = ElectricBlue,
                    modifier = Modifier.clickable {
                        isAllSelected = !isAllSelected
                        if (isAllSelected) {
                            photos.forEach { photo ->
                                if (selectedFiles.none { it.id == photo.id }) {
                                    selectedFiles.add(
                                        SelectedFile(
                                            id = photo.id,
                                            uri = photo.uri,
                                            name = photo.name,
                                            size = photo.size,
                                            mimeType = photo.mimeType,
                                            category = FileCategory.PHOTOS
                                        )
                                    )
                                }
                            }
                        } else {
                            photos.forEach { photo ->
                                selectedFiles.removeAll { it.id == photo.id }
                            }
                        }
                    }
                )
                Spacer(modifier = Modifier.width(16.dp))
                IconButton(onClick = onPickExternal) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Photos", tint = ElectricBlue)
                }
            }
        }

        if (photos.isEmpty()) {
            EmptyStateView(
                title = "No Local Photos Found",
                subtitle = "Tap + to select photos from system picker",
                onClickPicker = onPickExternal
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(photos) { photo ->
                    val isSelected = selectedFiles.any { it.id == photo.id }
                    MediaGridTile(
                        title = photo.name,
                        subtitle = formatSize(photo.size),
                        icon = Icons.Default.Image,
                        isSelected = isSelected,
                        onToggle = {
                            toggleMediaSelection(photo, selectedFiles)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun VideosTabContent(
    videos: List<LocalMediaItem>,
    selectedFiles: MutableList<SelectedFile>,
    onPickExternal: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Videos (${videos.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
            IconButton(onClick = onPickExternal) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Videos", tint = ElectricBlue)
            }
        }

        if (videos.isEmpty()) {
            EmptyStateView(
                title = "No Local Videos Found",
                subtitle = "Tap + to pick video files",
                onClickPicker = onPickExternal
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(videos) { video ->
                    val isSelected = selectedFiles.any { it.id == video.id }
                    MediaRowItem(
                        title = video.name,
                        subtitle = "${formatDuration(video.durationMs)} • ${formatSize(video.size)}",
                        icon = Icons.Default.Movie,
                        isSelected = isSelected,
                        onToggle = { toggleMediaSelection(video, selectedFiles) }
                    )
                }
            }
        }
    }
}

@Composable
private fun MusicTabContent(
    musicList: List<LocalMediaItem>,
    selectedFiles: MutableList<SelectedFile>,
    onPickExternal: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Music (${musicList.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
            IconButton(onClick = onPickExternal) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Music", tint = ElectricBlue)
            }
        }

        if (musicList.isEmpty()) {
            EmptyStateView(
                title = "No Local Audio Files Found",
                subtitle = "Tap + to select music tracks",
                onClickPicker = onPickExternal
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(musicList) { track ->
                    val isSelected = selectedFiles.any { it.id == track.id }
                    MediaRowItem(
                        title = track.name,
                        subtitle = "${track.artist} • ${formatSize(track.size)}",
                        icon = Icons.Default.AudioFile,
                        isSelected = isSelected,
                        onToggle = { toggleMediaSelection(track, selectedFiles) }
                    )
                }
            }
        }
    }
}

@Composable
private fun FilesTabContent(
    files: List<LocalMediaItem>,
    selectedFiles: MutableList<SelectedFile>,
    onPickExternal: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Documents & Files (${files.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
            IconButton(onClick = onPickExternal) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Browse Storage", tint = ElectricBlue)
            }
        }

        if (files.isEmpty()) {
            EmptyStateView(
                title = "No Document Files Found",
                subtitle = "Tap + to pick PDFs, ZIPs, or DOC files",
                onClickPicker = onPickExternal
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(files) { file ->
                    val isSelected = selectedFiles.any { it.id == file.id }
                    MediaRowItem(
                        title = file.name,
                        subtitle = "${file.category.label} • ${formatSize(file.size)}",
                        icon = Icons.Default.Description,
                        isSelected = isSelected,
                        onToggle = { toggleMediaSelection(file, selectedFiles) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryTabContent(
    historyList: List<TransferEntity>,
    fileManager: FileManager
) {
    val context = LocalContext.current
    var activeFilter by remember { mutableStateOf<TransferDirection?>(null) }

    val filteredList = remember(historyList, activeFilter) {
        if (activeFilter == null) historyList
        else historyList.filter { it.directionName == activeFilter?.name }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                label = "All (${historyList.size})",
                isSelected = activeFilter == null,
                onClick = { activeFilter = null }
            )
            FilterChip(
                label = "Sent (${historyList.count { it.directionName == TransferDirection.SENT.name }})",
                isSelected = activeFilter == TransferDirection.SENT,
                onClick = { activeFilter = TransferDirection.SENT }
            )
            FilterChip(
                label = "Received (${historyList.count { it.directionName == TransferDirection.RECEIVED.name }})",
                isSelected = activeFilter == TransferDirection.RECEIVED,
                onClick = { activeFilter = TransferDirection.RECEIVED }
            )
        }

        if (filteredList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No transfer history records yet", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredList) { record ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(ElectricBlue.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (record.directionName == TransferDirection.SENT.name) Icons.Default.CallMade else Icons.Default.CallReceived,
                                    contentDescription = null,
                                    tint = ElectricBlue
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = record.fileName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${formatSize(record.fileSize)} • ${formatTimestamp(record.timestamp)} • ${record.remoteDeviceName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = record.statusName,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (record.statusName == "COMPLETED") Color(0xFF10B981) else Color.Red
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MediaGridTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onToggle() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) ElectricBlue.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) ElectricBlue else SendoraDarkBorder
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Box(modifier = Modifier.align(Alignment.TopEnd)) {
                Icon(
                    imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (isSelected) ElectricBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun MediaRowItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onToggle() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) ElectricBlue.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) ElectricBlue else SendoraDarkBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(ElectricBlue.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = ElectricBlue)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (isSelected) ElectricBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
private fun EmptyStateView(
    title: String,
    subtitle: String,
    onClickPicker: () -> Unit
) {
    SendoraCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = Icons.Default.Folder, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onClickPicker,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Select Files")
            }
        }
    }
}

@Composable
private fun BottomTransferActionBar(
    selectedCount: Int,
    totalSizeBytes: Long,
    isConnected: Boolean,
    connectedDeviceName: String,
    onSend: () -> Unit,
    onReceive: () -> Unit,
    onConnect: () -> Unit,
    onClear: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            if (selectedCount > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(ElectricBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = selectedCount.toString(),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Selected (${formatSize(totalSizeBytes)})",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        text = "Clear",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.clickable { onClear() }
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onSend,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = if (selectedCount > 0) "SEND ($selectedCount)" else "SEND")
                }

                Button(
                    onClick = onReceive,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.CallReceived, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "RECEIVE", fontWeight = FontWeight.Bold)
                }

                IconButton(
                    onClick = onConnect,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = "Connect Device",
                        tint = ElectricBlue
                    )
                }
            }
        }
    }
}

@Composable
private fun FilterChip(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) ElectricBlue else MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal),
            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun toggleMediaSelection(item: LocalMediaItem, selectedFiles: MutableList<SelectedFile>) {
    val existing = selectedFiles.find { it.id == item.id }
    if (existing != null) {
        selectedFiles.remove(existing)
    } else {
        selectedFiles.add(
            SelectedFile(
                id = item.id,
                uri = item.uri,
                name = item.name,
                size = item.size,
                mimeType = item.mimeType,
                category = item.category
            )
        )
    }
}

private fun formatDuration(ms: Long): String {
    val totalSecs = ms / 1000
    val mins = totalSecs / 60
    val secs = totalSecs % 60
    return String.format(Locale.US, "%02d:%02d", mins, secs)
}

private fun formatTimestamp(millis: Long): String {
    val sdf = SimpleDateFormat("MMM dd, HH:mm", Locale.US)
    return sdf.format(Date(millis))
}

private fun formatSize(bytes: Long): String {
    return when {
        bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.1f GB", bytes / (1024f * 1024f * 1024f))
        bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f))
        bytes >= 1024 -> String.format(Locale.US, "%.0f KB", bytes / 1024f)
        else -> "$bytes B"
    }
}
