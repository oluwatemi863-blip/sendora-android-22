package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Brand Palette
val SendoraDarkBg = Color(0xFF050B18) // Rich Deep Navy Midnight
val SendoraDarkSurface = Color(0xFF0D1527) // Sophisticated Deep Surface
val SendoraDarkSurfaceVariant = Color(0xFF131F37) // Elevated Surface Variant
val SendoraDarkBorder = Color(0xFF1E2D4A) // Subtle Steel Blue Border
val SendoraDarkBorderLight = Color(0xFF2E4166) // Highlight Border

val SendoraLightBg = Color(0xFFF4F7FC)
val SendoraLightSurface = Color(0xFFFFFFFF)
val SendoraLightSurfaceVariant = Color(0xFFE8EEF8)
val SendoraLightBorder = Color(0xFFD0DCEE)

val ElectricBlue = Color(0xFF2563EB) // Electric Blue Accent
val ElectricBlueLight = Color(0xFF3B82F6)
val ElectricBlueDark = Color(0xFF1D4ED8)

val CyanAccent = Color(0xFF06B6D4) // Cyan Accent
val CyanAccentLight = Color(0xFF22D3EE)
val CyanAccentDark = Color(0xFF0891B2)

val PurpleAccent = Color(0xFFA855F7) // Violet Glow Accent

val DeepBluePrimary = Color(0xFF050B18)
val DeepBlueSecondary = Color(0xFF0D1527)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)

